

START TRANSACTION;



CREATE TABLE `admin` (
                         `id` int(11) NOT NULL,
                         `username` varchar(255) NOT NULL,
                         `password` varchar(255) NOT NULL,
                         `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP

);


INSERT INTO `admin` (`id`, `username`, `password`, `creationDate`) VALUES
(1, 'Oguzhan', '12345', '2017-01-24 16:21:18');


CREATE TABLE `course` (
                          `id` int(11) NOT NULL,
                          `courseCode` varchar(255) DEFAULT NULL,
                          `courseName` varchar(255) DEFAULT NULL,
                        `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP

);



INSERT INTO `course` (`id`, `courseCode`, `courseName`, `creationDate`) VALUES
(1, 'IT306', 'Socialmediawebanalytic',  '2017-02-11 17:39:10');




CREATE TABLE `courseenrolls` (
                                 `id` int(11) NOT NULL,
                                 `studentRegno` varchar(255) DEFAULT NULL,

                                 `course` int(11) DEFAULT NULL,
                                 `enrollDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
);



INSERT INTO `courseenrolls` (`id`, `studentRegno`,  `course`, `enrollDate`) VALUES
(4, '3131341', '715948',  '2018-05-21 10:19:41'),
(5, '151251', '131863',  '2018-08-25 05:52:34');





CREATE TABLE `students` (
                            `StudentRegno` varchar(255) NOT NULL,
                            `password` varchar(255) DEFAULT NULL,
                            `studentName` varchar(255) DEFAULT NULL,
                            `countries` varchar (255) DEFAULT NULL,
                            `gradeyear`varchar (255) DEFAULT NULL,
                            `creationdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP

);



INSERT INTO `students` (`StudentRegno`,  `password`, `studentName`,`countries`,`gradeyear`,`creationdate`) VALUES
('10806121',  'f925916e2754e5e03f75dd58a5733251', 'mehmet','Europe','1', '2017-02-11 19:38:32');




ALTER TABLE `admin`
    ADD PRIMARY KEY (`id`);


ALTER TABLE `course`
    ADD PRIMARY KEY (`id`);


ALTER TABLE `courseenrolls`
    ADD PRIMARY KEY (`id`);

ALTER TABLE `students`
    ADD PRIMARY KEY (`StudentRegno`);


ALTER TABLE `admin`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;




ALTER TABLE `course`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;


ALTER TABLE `courseenrolls`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;


