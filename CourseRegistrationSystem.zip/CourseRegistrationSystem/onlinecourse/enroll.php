<?php
session_start();
include('includes/config.php');



if(isset($_POST['submit']))
{
    $studentregno=$_POST['studentregno'];



    $course=$_POST['course'];

    $ret=mysqli_query($con,"insert into courseenrolls(studentRegno,course) values('$studentregno','$course')");

}
?>


<html>
<head>

    <title>Course Enroll</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>

<body>
<?php include('includes/header.php');?>
<?php include('includes/menubar.php');?>



<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="headline" style = "text-align: center">Course Enroll </h1>
            </div>
        </div>
        <div class="row" >
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="panel panel-default">


                    <?php $sql=mysqli_query($con,"select * from students where StudentRegno='".$_SESSION['login']."'");
                    $cnt=1;
                    while($row=mysqli_fetch_array($sql))
                    { ?>

                    <div class="panel-body">
                        <form name="dept" method="post" >
                            <div class="form-group">
                                <label for="studentname" style="color:red";>Student Name  </label>
                                <input type="text" class="form-control" id="studentname" name="studentname" value="<?php echo ($row['studentName']);?>"  />
                            </div>

                            <div class="form-group">
                                <label for="studentregno"style="color:red";>Student Reg No   </label>
                                <input type="text" class="form-control" id="studentregno" name="studentregno" value="<?php echo ($row['StudentRegno']);?>"  placeholder="Student Reg no" readonly />

                            </div>


                            <?php } ?>
                    </div>
                    <?php  ?>

                    <div class="form-group">
                        <label for="Course" style="padding-left: 15px; color:red";>Course  </label>
                        <select class="form-control" name="course" id="course"  required="required">
                            <option value=""  >Select Course</option>
                            <?php
                            $sql=mysqli_query($con,"select * from course");
                            while($row=mysqli_fetch_array($sql))
                            {
                                ?>
                                <option value="<?php echo ($row['id']);?>"><?php echo ($row['courseName']);?></option>
                            <?php } ?>
                        </select>

                    </div>



                    <button type="submit" name="submit" id="submit" style="background-color:brown; border-style: none;  color: white;" class="btn btn-default">Enroll </button>
                    </form>
                </div>
            </div>
        </div>







    </div>
</div>
<?php include('includes/footer.php');?>
<script src="assets/js/jquery-1.11.1.js"></script>
<script src="assets/js/bootstrap.js"></script>


</body>
</html>


