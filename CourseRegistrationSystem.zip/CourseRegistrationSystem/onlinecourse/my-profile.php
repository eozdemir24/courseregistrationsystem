
<?php
session_start();
include('includes/config.php');
error_reporting(0);


if(isset($_POST['submit']))
{
    $studentname=$_POST['studentname'];
    $countries=$_POST['countries'];
    $gradeyear=$_POST['gradeyear'];

    $ret=mysqli_query($con,"update students set studentName='$studentname',gradeyear='$gradeyear',countries='$countries'  where StudentRegno='".$_SESSION['login']."'");



    if($ret)
    {
        $_SESSION['msg']="Student Record updated Successfully !!";
    }
    else
    {
        $_SESSION['msg']="Error : Student Record not update";
    }
}
?>


<html>
<head>

    <title>Student Profile</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>

<body>
<?php include('includes/header.php');?>

<?php if($_SESSION['login']!="")
{
    include('includes/menubar.php');
}
?>

<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="headline" style = "text-align: center"> My Profile  </h1>
            </div>
        </div>
        <div class="row" >
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="panel panel-default">


                    <?php $sql=mysqli_query($con,"select * from students where StudentRegno='".$_SESSION['login']."'");
                    $cnt=1;
                    while($row=mysqli_fetch_array($sql))
                    { ?>

                    <div class="panel-body">
                        <form name="dept" method="post" >
                            <div class="form-group">
                                <label for="studentname" style="color:red"; >Student Name  </label>
                                <input type="text" class="form-control" id="studentname" name="studentname" value="<?php echo ($row['studentName']);?>"  />
                            </div>

                            <div class="form-group">
                                <label for="studentregno" style="color:red"; >Student Reg No   </label>
                                <input type="text" class="form-control" id="studentregno" name="studentregno" value="<?php echo ($row['StudentRegno']);?>"  placeholder="Student Reg Number" readonly />

                            </div>

                            <div class="form-group">
                                <label for="countries" style="color: red;"> Nations  </label>
                                <select name="countries"  value="<?php echo ($row['countries']);?>" class="form-control" id="countries" style="width:300px;">

                                    <option> Africa </option>
                                    <option> East Asia  </option>
                                    <option>Europe</option>
                                    <option>North America</option>
                                    <option>South America </option>
                                    <option>Middle East</option>
                                    <option> Oceania </option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="gradeyears"style="color: red;">Grade Year  </label> <br>

                                <input type="radio" name="gradeyear" value="1" <?php if ($gradeyear == '1') echo 'checked="checked"'; ?> /> 1
                                <input type="radio" name="gradeyear" value="2" <?php if ($gradeyear == '2') echo 'checked="checked"'; ?> /> 2
                                <input type="radio" name="gradeyear" value="3" <?php if ($gradeyear == '3') echo 'checked="checked"'; ?> /> 3
                                <input type="radio" name="gradeyear" value="4" <?php if ($gradeyear == '4') echo 'checked="checked"'; ?> /> 4

                            </div>






                            <?php } ?>

                            <button type="submit" name="submit" id="submit" style="background-color:brown; border-style: none;  color: white;" class="btn btn-default">Update</button>
                        </form>
                    </div>
                </div>
            </div>

        </div>

    </div>





</div>
</div>
<?php include('includes/footer.php');?>

<script src="assets/js/bootstrap.js"></script>


</body>
</html>
<?php ?>
