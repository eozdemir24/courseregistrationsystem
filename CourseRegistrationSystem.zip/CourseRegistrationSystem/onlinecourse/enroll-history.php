<?php
session_start();
include('includes/config.php');




if(isset($_GET['del']))
      {
              mysqli_query($con,"delete from course where id = '".$_GET['id']."'");

      }

?>

<html>
<head>

    <title>Enroll History</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>

<body>
<?php include('includes/header.php');?>
<?php include('includes/menubar.php');?>



    <div class="content">
        <div class="container">
              <div class="row">
                    <div class="col-md-12">
                        <h1 class="headline" style = "text-align: center">Enroll History  </h1>
                    </div>
                </div>
                <div class="row" >
            
                <div class="col-md-12">
                    
                    <div class="panel panel-default">

                        <div class="panel-body">
                            <div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th style="color:red"; >Course Name </th>
                                             <th style="color:red";>Enrollment Date</th>
                                             <th style="color:red";>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$sql=mysqli_query($con,"select courseenrolls.course as cid, course.courseName as courname,courseenrolls.enrollDate as edate  from courseenrolls join course on course.id=courseenrolls.course where courseenrolls.studentRegno='".$_SESSION['login']."'");
$cnt=1;
while($row=mysqli_fetch_array($sql))
{
?>


                                        <tr>
                                            <td><?php echo $cnt;?></td>
                                            <td><?php echo ($row['courname']);?></td>
                                             <td><?php echo ($row['edate']);?></td>
                                        <td>
										<a href="enroll-history.php?id=<?php echo $row['cid']?>&del=delete" >
                                            <button type="submit" name="submit" id="submit" style="background-color:brown; border-style: none;  color: white;" class="btn btn-default">Delete </button>
</a>
</td>
</tr>
<?php 
$cnt++;
} ?>

                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>





        </div>
    </div>

  <?php include('includes/footer.php');?>

    <script src="assets/js/bootstrap.js"></script>
</body>
</html>
<?php  ?>
