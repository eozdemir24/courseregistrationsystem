<nav class="navbar navbar-expand-lg navbar-mainbg">
<script src="pp.js"></script>
<link rel="stylesheet" href="style.css" />


    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto">
            <div class="hori-selector"><div class="left"></div><div class="right"></div></div>


            <li class="nav-item"><a class="nav-link" href="course.php"><i class="fas fa-tachometer-alt"></i>Course</a></li>
            <li class="nav-item "><a  class="nav-link" href="student-registration.php"><i class="far fa-address-book"></i>Registration</a></li>
            <li class="nav-item"> <a class="nav-link" href="manage-students.php"><i class="far fa-clone"></i>Manage Students</a></li>
            <li class="nav-item"> <a class="nav-link" href="userguide.php"><i class="far fa-clone"></i>User Guide</a></li>


            <li class="nav-item" > <a class="nav-link"  href="logout.php"> <i class= "fa-clone"></i>Logout</a></li>

        </ul>
    </div>
</nav>

