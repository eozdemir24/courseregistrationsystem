<?php
session_start();
include('includes/config.php');

if(isset($_GET['del']))
      {
              mysqli_query($con,"delete from students where StudentRegno = '".$_GET['id']."'");

      }

    
?>


<html >
<head>


    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>

<body>
<?php include('includes/header.php');?>
<?php include('includes/menubar.php');?>
    




    <div class="content">
        <div class="container">
              <div class="row">
                    <div class="col-lg-offset-2">
                        <h1 class="headline" style="text-align: center;"> Student Registered List  </h1>
                    </div>
                </div>
                <div class="row" >
                 

                <div class="col-md-12">


                        <div class="panel-heading">

                        </div>
                        <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead class="black white-text">
                                        <tr>
                                            <th>#</th>
                                            <th style="color:red"; >Reg No </th>
                                            <th style="color:red"; >Student Name </th>
                                            <th style="color:red"; >Countries</th>
                                            <th style="color:red"; >Grade Year</th>
                                            <th style="color:red"; >Reg Date</th>


                                             <th style="color:red"; >Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
<?php
$sql=mysqli_query($con,"select * from students");
$cnt=1;
while($row=mysqli_fetch_array($sql))
{
?>


                                        <tr>
                                            <td><?php echo $cnt;?></td>
                                            <td><?php echo ($row['StudentRegno']);?></td>
                                            <td><?php echo ($row['studentName']);?></td>
                                            <td><?php echo ($row['countries']);?></td>
                                            <td><?php echo ($row['gradeyear']);?></td>
                                            <td><?php echo ($row['creationdate']);?></td>
                                            <td>

                                       
     <a href="manage-students.php?id=<?php echo $row['StudentRegno']?>&del=delete"
                                            <button style="background-color:skyblue;border-style: none;"   class="btn btn-danger">Delete</button>
</a>

                                            </td>
                                        </tr>
<?php 
$cnt++;
} ?>

                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                     
                </div>
            </div>



    </div>

        </div>
    </div>
    
  <?php include('includes/footer.php');?>
    

   
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>
<?php  ?>
