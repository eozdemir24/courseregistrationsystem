<!DOCTYPE html>
<html>
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<link href="assets/css/font-awesome.css" rel="stylesheet" />
<link href="assets/css/style.css" rel="stylesheet" />


<div class="limiter">

    <div class="wrap-login100 p-t-30 p-b-50">
				<span class="login100-form-title p-b-41">
<?php include('includes/header.php');?>
                    <?php include('includes/menubar.php');?>
                    <body>
<style>

.xd{
    color: black;

    list-style-type: none;
    text-align: center;
    font-family: -apple-system;

}
body{
    background-image: none;


}



</style>



<div class="xd">
    <?php



    $lines =file('userguides.txt');
    foreach ($lines as $user){
        echo " <li class=list>$user </li>";


    }


    ?>

    <?php include('includes/footer.php');?>
</div>
</body>
</html>