<?php
session_start();
include('includes/config.php');


    if(isset($_POST['submit']))
    {
        $coursecode=$_POST['coursecode'];
        $coursename=$_POST['coursename'];


        $ret=mysqli_query($con,"insert into course(courseCode,courseName) values('$coursecode','$coursename')");

    }
    if(isset($_GET['del']))
    {
        mysqli_query($con,"delete from course where id = '".$_GET['id']."'");

    }
    ?>

    <!DOCTYPE html>
    <html>
    <head>

        <title>Admin | Course</title>
        <link href="assets/css/bootstrap.css" rel="stylesheet" />
        <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <link href="assets/css/style.css" rel="stylesheet" />

    </head>

    <body>
    <?php include('includes/header.php');?>
    <?php include('includes/menubar.php');?>


    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="headline" style="text-align: center">Course  </h1>
                </div>
            </div>
            <div class="row" >
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <div class="panel panel-default">




                        <div class="panel-body">
                            <form name="dept" method="post">
                                <div class="form-group">
                                    <label for="coursecode" style="color:red"; >Course Code  </label>
                                    <input type="text"   class="form-control" id="coursecode" name="coursecode" placeholder="Course Code" required />
                                </div>

                                <div class="form-group">
                                    <label for="coursename" style="color:red"; >Course Name  </label>
                                    <input type="text"   class="form-control" id="coursename" name="coursename" placeholder="Course Name" required />
                                </div>

                                <button type="submit"  name="submit" style="background-color:brown;border-style: none; color: whitesmoke;" class="btn btn-default">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

            <div class="col-md-12">

                <div class="panel panel-default">


                    <div class="panel-body">
                        <div class="table-responsive table-bordered">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th style="color:red"; >Course Code</th>
                                    <th style="color:red"; >Course Name </th>
                                    <th style="color:red";>Creation Date</th>
                                    <th style="color:red";> Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                $sql=mysqli_query($con,"select * from course");
                                $cnt=1;
                                while($row=mysqli_fetch_array($sql))
                                {
                                    ?>


                                    <tr>
                                        <td><?php echo $cnt;?></td>
                                        <td><?php echo $row['courseCode'];?></td>
                                        <td><?php echo $row['courseName'];?></td>


                                        <td><?php echo  $row['creationDate'];?></td>
                                        <td>

                                            <a href="course.php?id=<?php echo $row['id']?>&del=delete" >
                                                <button style="background-color:skyblue;border-style: none; color: whitesmoke;" class="btn btn-danger">Delete</button>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php
                                    $cnt++;
                                } ?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>





    </div>
    </div>

    <?php include('includes/footer.php');?>



    <script src="assets/js/bootstrap.js"></script>
    </body>
    </html>
<?php  ?>
