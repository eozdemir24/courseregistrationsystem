<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2020 Online Course Registration | By : Erkan Ozdemir Oktay Gormez
                </div>

            </div>
        </div>
    </footer>