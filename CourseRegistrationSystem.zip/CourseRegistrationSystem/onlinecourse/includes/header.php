
<html>

<!-- HEADER END-->
<div class="navbar navbar-inverse set-radius-zero">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <style>
                .container {
                    position: relative;
                    right: 105px;
                }



                img {
                    width: 20%;
                    height: auto;

                }
            </style>
            </head>
            <body>



            <div class="container">
                <img src="logo.jpg" alt="Cinque Terre" width="10">

            </div>



        </div>

        <div class="left-div">
            <p style="color:#fff; font-size:24px;4px; line-height:34px; text-align:center; padding:35px; ">

                Online Course Registration </p>
        </div>
    </div>
</div>

</html>